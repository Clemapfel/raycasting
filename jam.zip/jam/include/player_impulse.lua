PlayerImpulse_t = object_new_type("PlayerImpulse")

player_impulse_new = function(...)
    return player_impulse_init(object_new(PlayerImpulse_t, {
    }), ...)
end

player_impulse_init = function(self, ...)
    log_typecheck(self, PlayerImpulse_t)

    self.position_x = 0
    self.position_y = 0

    self.origin_x = 1
    self.origin_y = 1

    self.radius = 1
    self.angle = 0 -- radians
    self.meter = 0

    if select("#", ...) > 0 then
        player_impulse_reformat(self, ...)
    end

    return self
end

player_impulse_reformat = function(self, player_x, player_y, radius, cursor_x, cursor_y, meter)
    log_typecheck(self, PlayerImpulse_t, player_x, Number_t, player_y, Number_t, radius, Number_t, meter, Number_t)

    self.position_x, self.position_y = player_x, player_y
    self.radius = radius
    self.origin_x, self.origin_y = cursor_x, cursor_y
    self.meter = math_clamp(meter, 0, 1)
end

player_impulse_update = function(self, delta)
    log_typecheck(self, PlayerImpulse_t, delta, Number_t)
end

local function _radius_to_n_vertices(rx, ry)
    if ry == nil then ry = rx end
    return math.max(8, math.floor(math.sqrt(((rx + ry) / 2) * 20.0)))
end

player_impulse_draw = function(self)
    log_typecheck(self, PlayerImpulse_t)

    local outline_color = palette_black

    local line_w = 2
    local outline_offset = 2.0

    love.graphics.setLineJoin("miter")

    local inner_r = 4
    local x, y, r = self.position_x, self.position_y, self.radius

    local dx, dy = math_normalize(self.origin_x - self.position_x, self.origin_y - self.position_y)

    local line_r = r + _global_outer_margin

    local ax, ay = x + dx * line_r, y + dy * line_r
    local bx, by = x - dx * line_r, y - dy * line_r

    local head_len = 12
    local head_angle = math_tau / 12
    local c, s = math_cos(head_angle), math_sin(head_angle)

    local h1x, h1y = dx * c - dy * s, dx * s + dy * c
    local h2x, h2y = dx * c + dy * s, -dx * s + dy * c

    local function draw_arrow(ext)
        graphics_draw_line(ax + dx * ext, ay + dy * ext, bx, by)
        graphics_draw_line(
            bx + h1x * (head_len + ext), by + h1y * (head_len + ext),
            bx, by,
            bx + h2x * (head_len + ext), by + h2y * (head_len + ext))
    end

    rgba_bind(outline_color)
    graphics_set_line_state(line_w + outline_offset)
    draw_arrow(outline_offset * 0.5)

    rgba_bind(palette_get_current_color())
    graphics_set_line_state(line_w)
    draw_arrow(0)

    local meter_x, meter_y = math_mix2(x, y, ax, ay, self.meter)

    local half = 4 * inner_r
    local px, py = math_turn_left(dx, dy)

    local function draw_meter(ext)
        local h = half + ext
        graphics_draw_line(
            meter_x + px * h, meter_y + py * h,
            meter_x - px * h, meter_y - py * h)
    end

    rgba_bind(outline_color)
    graphics_draw_ellipse(x, y, inner_r + outline_offset)
    graphics_set_line_state(line_w + outline_offset)
    draw_arrow(outline_offset * 0.5)
    draw_meter(outline_offset * 0.5)

    rgba_bind(palette_get_current_color())
    graphics_draw_ellipse(x, y, inner_r)
    graphics_set_line_state(line_w)
    draw_arrow(0)
    draw_meter(0)
end

player_impulse_set_meter = function(self, t)
    log_typecheck(self, PlayerImpulse_t, t, Number_t)
    self.meter = t
end