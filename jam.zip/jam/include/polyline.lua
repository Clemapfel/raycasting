Polyline_t = object_new_type("Polyline")

--- @enum PolylineWinding
PolylineWinding = {
    CLOCKWISE = true,
    COUNTERCLOCKWISE = false
}

polyline_new = function(...)
    local self = object_new(Polyline_t, {
        vertices = {},
        n_vertices = 0,
        signed_area = 0,
        signed_area_needs_update = false
    })

    return polyline_init(self, ...)
end

polyline_init = function(self, ...)
    log_typecheck(self, Polyline_t)

    local first = select(1, ...)

    local vertices
    if object_is_table(first) then
        vertices = first
    else
        vertices = { ... }
    end

    local n = #vertices
    log_assert(n % 2 == 0 and n >= 6,  "In polyline_init: expected an even number of coordinates, at least 3 points")

    self.vertices = vertices
    self.n_vertices = math_divide_ints(n, 2)
    self.signed_area_needs_update = true -- vertices changed, cached area is invalid
    return self
end

polyline_get_vertices = function(self)
    log_typecheck(self, Polyline_t)
    return self.vertices
end

polyline_set_vertices = function(self, first, ...)
    if object_is_table(first) then
        log_typecheck(self, Polyline_t, first, Table_t, select(1, ...), Nil_t)
        self.vertices = first
    else
        log_typecheck_arg_i(self, Polyline_t, 1)
        for i = 1, select("#", ...) do
            local x = select(i, ...)
            log_typecheck_arg_(x, Number_t, 2 + i)
        end

        self.vertices = { ... }
    end
end

polyline_translate = function(self, x, y)
    log_typecheck(self, Polyline_t, x, Number_t, y, Number_t)
    local data = self.vertices
    for i = 1, table_sizeof(self.vertices), 2 do
        data[i + 0] = data[i + 0] + x
        data[i + 1] = data[i + 1] + y
    end
    return self
end

polyline_draw = function(self)
    log_typecheck(self, Polyline_t)

    local data = self.vertices
    local n = table_sizeof(data)

    for i = 1, n - 2, 2 do
        graphics_draw_line(data[i + 0], data[i + 1], data[i + 2], data[i + 3])
    end
    graphics_draw_line(data[n - 1], data[n - 0], data[1], data[2])

    return self
end

polyline_close = function(self)
    log_typecheck(self, Polyline_t)

    local data = self.vertices
    local n = #data
    local ax, ay = data[1], data[2]
    local bx, by = data[n - 1], data[n]
    if math_distance(ax, ay, bx, by) > 1 then
        table_push(data, ax)
        table_push(data, ay)
        self.n_vertices = self.n_vertices + 1
        self.signed_area_needs_update = true
    end
    return self
end

polyline_is_closed = function(self)
    log_typecheck(self, Polyline_t)

    local data = self.vertices
    local n = #data
    return math_distance(data[1], data[2], data[n - 1], data[n]) <= 1
end

polyline_get_n_nodes = function(self)
    log_typecheck(self, Polyline_t)

    local n = table_sizeof(self.vertices) / 2
    if polyline_is_closed(self) then
        n = n - 1
    end
    return n
end

polyline_get_signed_area = function(self)
    log_typecheck(self, Polyline_t)

    if not self.signed_area_needs_update then
        return self.signed_area
    end

    local vertices = self.vertices
    local n = polyline_get_n_nodes(self)

    local area = 0
    for i = 1, n do
        local next_i = i % n + 1
        local ai = (i - 1) * 2 + 1
        local bi = (next_i - 1) * 2 + 1
        area = area + 0.5 * math_cross(vertices[ai + 0], vertices[ai + 1], vertices[bi + 0], vertices[bi + 1])
    end

    self.signed_area = area
    self.signed_area_needs_update = false
    return area
end

polyline_get_winding = function(self)
    log_typecheck(self, Polyline_t)
    if polyline_get_signed_area(self) >= 0 then
        return PolylineWinding.CLOCKWISE
    else
        return PolylineWinding.COUNTERCLOCKSWISE
    end
end

polyline_get_aabb = function(self)
    log_typecheck(self, Polyline_t)

    local min_x, min_y, max_x, max_y = math_positive_inf, math_positive_inf, math_negative_inf, math_negative_inf

    local vertices = self.vertices
    local n = table_sizeof(vertices)

    for i = 1, n, 2 do
        local x, y = vertices[i], vertices[i + 1]
        if x < min_x then min_x = x end
        if y < min_y then min_y = y end
        if x > max_x then max_x = x end
        if y > max_y then max_y = y end
    end

    return aabb_new(min_x, min_y, max_x - min_x, max_y - min_y)
end

polyline_get_vertex = function(self, index)
    log_typecheck(self, Polyline_t, index, Number_t)

    local n = polyline_get_n_nodes(self)
    log_assert(index >= 1 and index <= n, "In polyline_get_vertex: index out of range")

    local i = (index - 1) * 2 + 1
    local data = self.vertices
    return data[i + 0], data[i + 1]
end

polyline_get_edge = function(self, index)
    log_typecheck(self, Polyline_t, index, Number_t)

    local n = polyline_get_n_nodes(self)
    log_assert(index >= 1 and index <= n, "In polyline_get_edge: index out of range")

    local next_index = index % n + 1 -- closed contour
    local ai = (index - 1) * 2 + 1
    local bi = (next_index - 1) * 2 + 1
    local data = self.vertices

    return data[ai + 0], data[ai + 1], data[bi + 0], data[bi + 1]
end

polyline_test_circle = function(self, px, py, pr)
    log_typecheck(self, Polyline_t, px, Number_t, py, Number_t, pr, Number_t)

    local vertices = polyline_get_vertices(self)
    local n = polyline_get_n_nodes(self)
    local radius_sq = pr * pr
    local indices = {}
    local distances = {}

    for i = 1, n do
        local j = i % n + 1
        local ai = (i - 1) * 2 + 1
        local bi = (j - 1) * 2 + 1
        local ax, ay = vertices[ai + 0], vertices[ai + 1]
        local bx, by = vertices[bi + 0], vertices[bi + 1]
        local dx, dy = bx - ax, by - ay
        local length_sq = math_dot(dx, dy, dx, dy)

        local t = 0
        if length_sq > 0 then
            t = math_clamp(math_dot(px - ax, py - ay, dx, dy) / length_sq, 0, 1)
        end

        local cx, cy = ax + dx * t, ay + dy * t
        local ox, oy = px - cx, py - cy
        local distance_sq = math_dot(ox, oy, ox, oy)
        if math_dot(ox, oy, ox, oy) <= radius_sq then
            table_push(indices, i)
            distances[i] = distance_sq
        end
    end

    table_sort(indices, function(a, b)
        return distances[a] < distances[b]
    end)

    return indices
end

polyline_test_point = function(self, px, py)
    log_typecheck(self, Polyline_t, px, Number_t, py, Number_t)

    local data = self.vertices
    local n = polyline_get_n_nodes(self)

    local last = (n - 1) * 2 + 1
    local ax, ay = data[last + 0], data[last + 1]
    local winding = 0

    for i = 1, n * 2, 2 do
        local bx, by = data[i + 0], data[i + 1]

        if ay <= py then
            if by > py then -- upward crossing
                if (bx - ax) * (py - ay) - (px - ax) * (by - ay) > 0 then
                    winding = winding + 1
                end
            end
        elseif by <= py then -- downward crossing
            if (bx - ax) * (py - ay) - (px - ax) * (by - ay) < 0 then
                winding = winding - 1
            end
        end

        ax, ay = bx, by
    end

    return winding ~= 0
end

polyline_test_segment = function(self, origin_x, origin_y, direction_x, direction_y)
    log_typecheck(self, Polyline_t,
        origin_x, Number_t, origin_y, Number_t,
        direction_x, Number_t, direction_y, Number_t)

    local vertices = polyline_get_vertices(self)
    local n = polyline_get_n_nodes(self)
    local indices = {}
    local distances = {}

    local eps = math_eps
    local direction_length_sq = math_dot(direction_x, direction_y, direction_x, direction_y)
    local direction_length = math_magnitude(direction_x, direction_y)

    log_assert(direction_length > eps, "In polyline_test_segment: segment has length 0")
    local parameter_eps = eps / direction_length

    for i = 1, n do
        local j = i % n + 1
        local ai = (i - 1) * 2 + 1
        local bi = (j - 1) * 2 + 1
        local ax, ay = vertices[ai], vertices[ai + 1]
        local bx, by = vertices[bi], vertices[bi + 1]
        local edge_x, edge_y = bx - ax, by - ay
        local edge_length_sq = math_dot(edge_x, edge_y, edge_x, edge_y)
        local offset_x, offset_y = ax - origin_x, ay - origin_y
        local t
        local overlaps = false

        if edge_length_sq >= eps * eps then -- disregard degenerate segments
            local edge_length = math_magnitude(edge_x, edge_y)
            local denominator = math_cross(direction_x, direction_y, edge_x, edge_y)

            if math_max(denominator, -denominator) > eps * direction_length * edge_length then
                -- non-parallel
                t = math_cross(offset_x, offset_y, edge_x, edge_y) / denominator
                local u = math_cross(offset_x, offset_y, direction_x, direction_y) / denominator
                local edge_parameter_eps = eps / edge_length
                overlaps = t >= -parameter_eps and t <= 1 + parameter_eps
                    and u >= -edge_parameter_eps and u <= 1 + edge_parameter_eps
            else
                -- parallel
                local collinear_cross = math_cross(offset_x, offset_y, direction_x, direction_y)
                if math_max(collinear_cross, -collinear_cross) <= eps * direction_length then
                    local end_offset_x = bx - origin_x
                    local end_offset_y = by - origin_y
                    local t0 = math_dot(offset_x, offset_y, direction_x, direction_y) / direction_length_sq
                    local t1 = math_dot(end_offset_x, end_offset_y, direction_x, direction_y) / direction_length_sq
                    local overlap_start = math_max(0, math_min(t0, t1))
                    local overlap_end = math_min(1, math_max(t0, t1))

                    if overlap_start <= overlap_end + parameter_eps then
                        t = math_clamp(overlap_start, 0, 1)
                        overlaps = true
                    end
                end
            end
        end

        if overlaps then
            table_push(indices, i)
            distances[i] = math_clamp(t, 0, 1)
        end
    end

    table_sort(indices, function(a, b)
        if distances[a] == distances[b] then
            return a < b
        end
        return distances[a] < distances[b]
    end)

    return indices
end

polyline_get_circumcircle = function(self)
    log_typecheck(self, Polyline_t)

    local vertices = self.vertices

    local cx, cy = 0, 0
    for i = 1, table_sizeof(vertices), 2 do
        cx = cx + vertices[i + 0]
        cy = cy + vertices[i + 1]
    end

    cx, cy = cx / self.n_vertices, cy / self.n_vertices

    local max_distance = math_negative_inf
    for i = 1, table_sizeof(vertices), 2 do
        max_distance = math_max(max_distance, math_distance(cx, cy, vertices[i + 0], vertices[i + 1]))
    end

    return cx, cy, max_distance
end

polyline_get_center_of_mass = function(self)
    log_typecheck(self, Polyline_t)

    local vertices = self.vertices
    local n = polyline_get_n_nodes(self)

    local rx, ry = vertices[1], vertices[2]
    local cross_sum = 0
    local cx, cy = 0, 0
    local far_magnitude, far_x, far_y = 0, 0, 0

    for i = 1, n do
        local j = i % n + 1
        local ai = (i - 1) * 2 + 1
        local bi = (j - 1) * 2 + 1
        local ax, ay = vertices[ai + 0] - rx, vertices[ai + 1] - ry
        local bx, by = vertices[bi + 0] - rx, vertices[bi + 1] - ry

        local cross = math_cross(ax, ay, bx, by)
        cross_sum = cross_sum + cross
        cx = cx + (ax + bx) * cross
        cy = cy + (ay + by) * cross

        local dist = math_dot(ax, ay, ax, ay)
        if dist > far_magnitude then
            far_magnitude, far_x, far_y = dist, ax, ay
        end
    end

    if far_magnitude < math_eps * math_eps then
        return rx, ry
    end

    if math_max(cross_sum, -cross_sum) <= math_eps * far_magnitude then
        local dir_x, dir_y = math_normalize(far_x, far_y)

        local min_t, max_t = math_positive_inf, math_negative_inf
        for i = 1, n do
            local vi = (i - 1) * 2 + 1
            local t = math_dot(vertices[vi + 0] - rx, vertices[vi + 1] - ry, dir_x, dir_y)
            if t < min_t then min_t = t end
            if t > max_t then max_t = t end
        end

        local mid = (min_t + max_t) * 0.5
        return rx + dir_x * mid, ry + dir_y * mid
    end

    local factor = 1 / (3 * cross_sum)
    return rx + cx * factor, ry + cy * factor
end

polyline_cast_ray = function(self, x, y, dx, dy)
    log_typecheck(self, Polyline_t,
        x, Number_t, y, Number_t,
        dx, Number_t, dy, Number_t)

    local vertices = polyline_get_vertices(self)
    local n = polyline_get_n_nodes(self)

    local eps = math_eps
    local direction_length_sq = math_dot(dx, dy, dx, dy)
    local direction_length = math_magnitude(dx, dy)

    log_assert(direction_length > eps, "In polyline_cast_ray: ray has length 0")
    local parameter_eps = eps / direction_length

    local min_t = math_positive_inf

    for i = 1, n do
        local j = i % n + 1
        local ai = (i - 1) * 2 + 1
        local bi = (j - 1) * 2 + 1
        local ax, ay = vertices[ai], vertices[ai + 1]
        local bx, by = vertices[bi], vertices[bi + 1]
        local edge_x, edge_y = bx - ax, by - ay
        local edge_length_sq = math_dot(edge_x, edge_y, edge_x, edge_y)
        local offset_x, offset_y = ax - x, ay - y

        if edge_length_sq >= eps * eps then
            local edge_length = math_magnitude(edge_x, edge_y)
            local denominator = math_cross(dx, dy, edge_x, edge_y)

            if math_max(denominator, -denominator) > eps * direction_length * edge_length then
                -- non-parallel
                local t = math_cross(offset_x, offset_y, edge_x, edge_y) / denominator
                local u = math_cross(offset_x, offset_y, dx, dy) / denominator
                local edge_parameter_eps = eps / edge_length

                if t >= -parameter_eps and t <= 1 + parameter_eps
                    and u >= -edge_parameter_eps and u <= 1 + edge_parameter_eps then
                    t = math_clamp(t, 0, 1)
                    if t < min_t then min_t = t end
                end
            else
                -- parallel, only hits if collinear
                local collinear_cross = math_cross(offset_x, offset_y, dx, dy)
                if math_max(collinear_cross, -collinear_cross) <= eps * direction_length then
                    local t0 = math_dot(offset_x, offset_y, dx, dy) / direction_length_sq
                    local t1 = math_dot(bx - x, by - y, dx, dy) / direction_length_sq
                    local overlap_start = math_max(0, math_min(t0, t1))
                    local overlap_end = math_min(1, math_max(t0, t1))

                    if overlap_start <= overlap_end + parameter_eps then
                        local t = math_clamp(overlap_start, 0, 1)
                        if t < min_t then min_t = t end
                    end
                end
            end
        end
    end

    if min_t == math_positive_inf then
        return nil, nil
    end

    return x + dx * min_t, y + dy * min_t
end