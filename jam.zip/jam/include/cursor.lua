Cursor_t = object_new_type("cursor")

CursorType = {
    DEFAULT = "DEFAULT",
    CAN_CLICK = "CAN_CLICK",
    CANNOT_CLICK = "CANNOT_CLICK",
    CROSSHAIR = "CROSSHAIR"
}

local _height, _width = 6 * 3, 6 * 1

cursor_new = function(x, y)
    x = x or 0
    y = y or 0
    log_typecheck(x, Number_t, y, Number_t)

    return object_new(Cursor_t, {
        cursor_type = CursorType.DEFAULT,
        position_x = x,
        position_y = y
    })
end

cursor_set_type = function(self, cursor_type)
    log_typecheck(self, Cursor_t)
    log_typecheck_enum(cursor_type, CursorType)
    self.cursor_type = cursor_type
    return self
end

cursor_get_type = function(self)
    log_typecheck(self, Cursor_t)
    return self.cursor_type
end

cursor_set_position = function(self, x, y)
    log_typecheck(self, Cursor_t, x, Number_t, y, Number_t)
    self.position_x = x
    self.position_y = y
    return self
end

cursor_get_position = function(self)
    log_typecheck(self, Cursor_t)
    return self.position_x, self.position_y
end

local _cursor_get_color = function()
    local hue = love.timer.getTime() / 10
    return rgba_lighten(lcha_to_rgba(lcha_new(0.8, 1, hue, 1)), 1.5)
end

local _cursor_build_circle = function(x, y, radius, scale, n_vertices)
    local points = {}
    for i = 1, n_vertices + 1 do
        local angle = (i - 1) / n_vertices * math_tau
        table_push(points, x + math_cos(angle) * radius * scale)
        table_push(points, y + math_sin(angle) * radius * scale)
    end
    return points
end

local _cursor_draw_pointer = function(x, y, scale)
    log_typecheck(x, Number_t, y, Number_t, scale, Number_t)

    local width = _width * scale
    local height = _height * scale

    local outer_angle = math_degrees_to_radians(45)
    local divet_angle = math_degrees_to_radians(180 - 45)

    x = x - 0.5 * width
    y = y - 0.5 * height

    local a_x, a_y = x, y
    local b_x, b_y = x + math_cos(outer_angle) * height, y + math_sin(outer_angle) * height
    local c_x, c_y = x, y + height

    -- midpoint between lower
    local mid_x, mid_y = math_mix2(b_x, b_y, c_x, c_y, 0.5)

    -- move towards tip
    local dx, dy = math_normalize(a_x - mid_x, a_y - mid_y)

    -- height of triangle between outer tips, given angle
    local h = (math_distance(b_x, b_y, c_x, c_y) / 2) / math_tan(divet_angle / 2)
    mid_x, mid_y = mid_x + dx * h, mid_y + dy * h

    rgba_bind(palette_black)
    love.graphics.polygon("fill", {
        a_x, a_y,
        b_x, b_y,
        mid_x, mid_y
    })

    love.graphics.polygon("fill", {
        a_x, a_y,
        mid_x, mid_y,
        c_x, c_y
    })

    local line_width = 2 * scale
    local outline = {
        a_x, a_y,
        b_x, b_y,
        mid_x, mid_y,
        c_x, c_y,
        a_x, a_y
    }

    -- still black
    graphics_set_line_state(line_width + 1)
    graphics_draw_line(outline)

    rgba_bind(_cursor_get_color())
    graphics_set_line_state(line_width)
    graphics_draw_line(outline)
end

local _cursor_draw_can_click = function(x, y, scale)
    log_typecheck(x, Number_t, y, Number_t, scale, Number_t)

    local radius = math_mix(_width, _height, 0.5) * 0.6
    local line_width = 0.4 * radius
    local points = _cursor_build_circle(x, y, radius, scale, 16)

    rgba_bind(palette_black)
    graphics_set_line_state(line_width * scale + 2)
    graphics_draw_line(points)

    rgba_bind(_cursor_get_color())
    graphics_set_line_state(line_width * scale)
    graphics_draw_line(points)
end

local _cursor_draw_cannot_click = function(x, y, scale)
    log_typecheck(x, Number_t, y, Number_t, scale, Number_t)

    local radius = math_mix(_width, _height, 0.5) * 0.6
    local line_width = 0.4 * radius
    local points = _cursor_build_circle(x, y, radius, scale, 16)

    local cross = {
        x - radius + line_width, y + radius - line_width,
        x + radius - line_width, y - radius + line_width
    }

    rgba_bind(palette_black)
    graphics_set_line_state(line_width * scale + 2)
    graphics_draw_line(points)
    graphics_draw_line(cross)

    rgba_bind(_cursor_get_color())
    graphics_set_line_state(line_width * scale)
    graphics_draw_line(points)
    graphics_draw_line(cross)
end

local _cursor_draw_crosshair = function(x, y, scale)
    log_typecheck(x, Number_t, y, Number_t, scale, Number_t)

    local radius = math_mix(_width, _height, 0.5) * 0.6
    local line_width = 2
    local outline_width = 1

    local tick_inner = 0.35 * radius * scale
    local tick_outer = 1.6 * radius * scale

    local inner_o = tick_inner - outline_width
    local outer_o = tick_outer + outline_width

    --local points = _cursor_build_circle(x, y, radius, scale, 16)
    local dot_radius = 0.25 * line_width * scale

    -- outline
    rgba_bind(palette_black)
    graphics_set_line_state(line_width * scale + outline_width * 2)
    --graphics_draw_line(points)
    graphics_draw_line(x, y - inner_o, x, y - outer_o)
    graphics_draw_line(x, y + inner_o, x, y + outer_o)
    graphics_draw_line(x - inner_o, y, x - outer_o, y)
    graphics_draw_line(x + inner_o, y, x + outer_o, y)

    -- foreground
    rgba_bind(_cursor_get_color())
    graphics_set_line_state(line_width * scale)
    --graphics_draw_line(points)
    graphics_draw_line(x, y - tick_inner, x, y - tick_outer)
    graphics_draw_line(x, y + tick_inner, x, y + tick_outer)
    graphics_draw_line(x - tick_inner, y, x - tick_outer, y)
    graphics_draw_line(x + tick_inner, y, x + tick_outer, y)
end

cursor_draw = function(self)
    log_typecheck(self, Cursor_t)

    graphics_push_state()
    graphics_reset_transform()

    local x, y = self.position_x, self.position_y
    local scale = love.window.getDPIScale()

    if self.cursor_type == CursorType.DEFAULT then
        _cursor_draw_pointer(x, y, scale)
    elseif self.cursor_type == CursorType.CAN_CLICK then
        _cursor_draw_can_click(x, y, scale)
    elseif self.cursor_type == CursorType.CANNOT_CLICK then
        _cursor_draw_cannot_click(x, y, scale)
    elseif self.cursor_type == CursorType.CROSSHAIR then
        _cursor_draw_crosshair(x, y, scale)
    end

    love.graphics.pop()
    return self
end

cursor_update = function(self, delta)
    log_typecheck(self, Cursor_t, delta, Number_t)
end