Mesh_t = object_new_type("Mesh")

GraphicsBufferUsage = {
    STATIC = "static",
    DYNAMIC = "dynamic",
    STREAM = "stream"
}

mesh_new = function(data, usage)
    log_typecheck_arg_i(data, Table_t, 1)
    if usage == nil then usage = GraphicsBufferUsage.DYNAMIC end
    log_typecheck_enum(usage, GraphicsBufferUsage, 2)

    return object_new(Mesh_t, {
        native = love.graphics.newMesh(data, "triangles", usage)
    })
end

mesh_set_texture = function(self, texture)
    log_typecheck(self, Mesh_t, texture, Optional_t(Texture_t))

    if texture == nil then
        self.native:setTexture(nil)
    else
        self.native:setTexture(texture.native)
    end
end

mesh_draw = function(self, ...)
    log_typecheck(self, Mesh_t)
    love.graphics.draw(self.native, ...)
end

mesh_update_vertices = function(self, data)
    log_typecheck(self, Mesh_t, data, Table_t)
    self.native:setVertices(data)
end