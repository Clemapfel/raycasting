Player_t = object_new_type("Player")

local _settings_min_node_count = 32
local _settings_node_density = 1 / 5
local _settings_outline_width = 4

player_new = function(...)
    return player_init(object_new(Player_t, {
        softbody = nil,
        softbody_centroid_x = 0,
        softbody_centroid_y = 0,

        radius = nil,
        color = nil,

        position_x = 0,
        position_y = 0,

        linear_velocity_requests = {}, -- Table<Any, { dx, dy }>
        angular_velocity_requests = {}, -- Table<Any, { theta }>
        volume_requests = {}, -- Table<Any, { volume }>
        constraint_mode_requests = {}, -- Table<Any, { mode }>

        is_frozen = false,
        is_active = false,
        is_clickable = false,
    }), ...)
end

player_init = function(self, x, y, radius)
    log_typecheck(self, Player_t, x, Number_t, y, Number_t, radius, Number_t)

    local n_nodes = math_ceil(math_max(
        _settings_min_node_count,
        _settings_node_density * math_tau * radius
    ))

    if self.body ~= nil and radius == self.radius then
        self.body = softbody_init(self.body, x, y, radius, n_nodes)
    else
        self.body = softbody_new(x, y, radius, n_nodes)
    end

    self.position_x = x
    self.position_y = y
    self.radius = radius
    self.color = rgba_new(1, 1, 1, 1)

    return self
end

player_update = function(self, delta)
    log_typecheck(self, Player_t, delta, Number_t)

    -- integrate forces
    local dx, dy = 0, 0
    for entry in iter_values(self.linear_velocity_requests) do
        dx = dx + entry.dx
        dy = dy + entry.dy
    end

    local theta = 0
    for entry in iter_values(self.angular_velocity_requests) do
        theta = theta + entry.dtheta
    end

    local volume = 1
    for entry in iter_values(self.volume_requests) do
        volume = volume * entry.volume
    end

    local mode = SoftbodyConstraintMode.SOLID
    for entry in iter_values(self.constraint_mode_requests) do
        if entry.mode == SoftbodyConstraintMode.LIQUID then
            mode = SoftbodyConstraintMode.LIQUID
            break
        end
    end

    softbody_remove_linear_force(self.body, self.softbody_linear_force)
    self.softbody_linear_force = softbody_add_linear_force(self.body, dx, dy)

    softbody_remove_angular_force(self.body, self.softbody_angular_force)
    self.softbody_angular_force = softbody_add_angular_force(self.body, 0)

    softbody_set_target_volume(self.body, volume)

    if self.is_frozen ~= true then
        softbody_update(self.body, delta)
    end

    return self
end

player_request_linear_velocity = function(self, instance, dx, dy)
    log_typecheck(self, Player_t, instance, Table_t)

    if dx == nil or dy == nil then
        -- remove request
        log_typecheck_arg_i(dx, Nil_t, 3)
        log_typecheck_arg_i(dy, Nil_t, 4)

        self.linear_velocity_requests[instance] = nil
    else
        -- add / update request
        log_typecheck_arg_i(dx, Number_t, 3)
        log_typecheck_arg_i(dy, Number_t, 4)

        local current = self.linear_velocity_requests[instance]
        if current ~= nil then
            current.dx = dx
            current.dy = dy
        else
            self.linear_velocity_requests[instance] = {
                dx = dx,
                dy = dy
            }
        end
    end

    return self
end

player_request_angular_velocity = function(self, instance, dtheta)
    log_typecheck(self, Player_t, instance, Table_t)

    if dtheta == nil then
        self.angular_velocity_requests[instance] = nil
    else
        log_typecheck_arg_i(dtheta, Number_t, 3)
        local current = self.angular_velocity_requests[instance]
        if current ~= nil then
            current.dtheta = dtheta
        else
            self.angular_velocity_requests[instance] = {
                dtheta = dtheta
            }
        end
    end

    return self
end

player_request_volume_multiplier = function(self, instance, fraction)
    log_typecheck(self, Player_t, instance, Table_t)
    log_assert(fraction >= 0, "In player_request_volume_multiplier: fraction must be non-negative")

    if fraction == nil then
        self.volume_requests[instance] = nil
    else
        log_typecheck_arg_i(dtheta, Number_t, 3)
        local current = self.volume_requests[instance]
        if current ~= nil then
            current.volume = fraction
        else
            self.volume_requests[instance] = {
                volume = fraction
            }
        end
    end

    return self
end

player_request_constraint_mode = function(self, instance, mode)
    log_typecheck(self, Player_t, instance, Table_t)
    if mode ~= nil then
        log_typecheck_enum(mode, SoftbodyConstraintMode, 3)
    end

    if mode == nil then
        self.constraint_mode_requests[instance] = nil
    else
        local current = self.constraint_mode_requests[instance]
        if current ~= nil then
            current.mode = mode
        else
            self.constraint_mode_requests[instance] = {
                mode = mode
            }
        end
    end

    return self
end

player_clear_linear_velocity_requests = function(self)
    log_typecheck(self, Player_t)

    table_clear(self.linear_velocity_requests)
    return self
end

player_clear_angular_velocity_requests = function(self)
    log_typecheck(self, Player_t)

    table_clear(self.angular_velocity_requests)
    return self
end

player_clear_volume_requests = function(self)
    log_typecheck(self, Player_t)

    table_clear(self.volume_requests)
    return self
end

player_clear_constraint_mode_requests = function(self)
    log_typecheck(self, Player_t)

    table_clear(self.constraint_mode_requests)
    return self
end

player_set_collision_contours = function(self, contours)
    log_typecheck(self, Player_t, contours, Table_t)
    softbody_set_collision_contours(self.body, contours)

    return self
end

player_apply_linear_impulse = function(self, dx, dy)
    log_typecheck(self, Player_t, dx, Number_t, dy, Number_t)
    softbody_add_linear_impulse(self.body, dx, dy)
end

player_set_gravity = function(self, dx, dy)
    log_typecheck(self, Player_t, dx, Number_t, dy, Number_t)
    softbody_set_gravity(self.body, dx, dy)
end

player_set_is_clickable = function(self, b)
    if b == nil then b = true end
    log_typecheck(self, Player_t, b, Boolean_t)
    self.is_clickable = b
end

player_get_is_clickable = function(self)
    log_typecheck(self, Player_t)
    return self.is_clickable
end

player_set_is_active = function(self, b)
    if b == nil then b = true end
    log_typecheck(self, Player_t, b, Boolean_t)
    self.is_active = b
end

player_get_is_active = function(self)
    log_typecheck(self, Player_t)
    return self.is_active
end

player_draw = function(self)
    log_typecheck(self, Player_t)

    local outline = softbody_get_draw_contour(self.body)

    local vertices = polyline_get_vertices(outline)
    if self.triangulator == nil then
        self.triangulator = delaunay_new()
    end

    delaunay_triangulate(self.triangulator, vertices, vertices)
    local tris = delaunay_get_triangles(self.triangulator)
    local hull = delaunay_get_hull(self.triangulator)

    local bounds = polyline_get_aabb(polyline_new(hull))

    local data = {}
    for _, tri in ipairs(tris) do
        for i = 1, #tri, 2 do
            local x, y = tri[i + 0], tri[i + 1]
            local angle = math_angle(x, y)
            local u = (x - bounds.x) / bounds.width
            local v = (y - bounds.y) / bounds.height
            table.insert(data, { x, y, u, v, 1, 1, 1, 0.5 })
        end
    end

    rgba_bind(self.color)
    if self.mesh == nil or self.last_tris == nil or #tris ~= self.last_tris then
        self.mesh = mesh_new(data)
    else
        mesh_update_vertices(self.mesh, GraphicsBufferUsage.DYNAMIC)
    end

    mesh_draw(self.mesh)

    rgba_bind(palette_black)
    graphics_set_line_state(_settings_outline_width + 2)
    polyline_draw(outline)

    rgba_bind(self.color)
    graphics_set_line_state(_settings_outline_width)
    polyline_draw(outline)

    return self
end

player_get_player_collision_contour = function(self)
    log_typecheck(self, Player_t)

    return softbody_get_contour(self.body)
end

player_set_texture = function(self, texture)
    log_typecheck(self, Player_t, texture, Optional_t(Texture_t))
end

player_get_position = function(self)
    log_typecheck(self, Player_t)

    return softbody_get_centroid(self.body)
end

player_get_radius = function(self)
    log_typecheck(self, Player_t)
    return self.radius
end

player_get_circumcircle = function(self)
    log_typecheck(self, Player_t)
    local contour = softbody_get_contour(self.body)
    if contour ~= nil then
        return polyline_get_circumcenter(contour)
    else
        return 0, 0
    end
end

player_set_is_frozen = function(self, b)
    log_typecheck(self, Player_t, b, Boolean_t)
    if b then
        softbody_set_anchor(self.body, softbody_get_centroid(self.body))
        softbody_set_is_anchored(self.body, true)
    else
        softbody_set_is_anchored(self.body, false)
    end
end

player_set_is_liquid = function(self, b)
    log_typecheck(self, Player_t, b, Boolean_t)

    if b then
        softbody_set_constraint_mode(self.body, SoftbodyConstraintMode.LIQUID)
    else
        softbody_set_constraint_mode(self.body, SoftbodyConstraintMode.SOLID)
    end
end

player_get_is_liquid = function(self)
    log_typecheck(self, Player_t)
    return softbody_get_constraint_mode(self.body) == SoftbodyConstraintMode.LIQUID
end

player_set_is_anchored = function(self, b, x, y)
    log_typecheck(self, Player_t, b, Boolean_t)

    if b then
        softbody_set_anchor(self.body, x, y)
        softbody_set_is_anchored(self.body, true)
    else
        softbody_set_is_anchored(false)
    end
end

player_clear_forces = function(self)
    log_typecheck(self, Player_t)
    softbody_clear_forces(self.body)
end

player_set_color = function(self, rgba)
    log_typecheck(self, Player_t, rgba, RGBA_t)
    self.color = rgba
end