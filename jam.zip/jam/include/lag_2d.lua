Lag2_t = object_new_type("lag2d")

local lag_step = function(current, target, attack_speed, decay_speed, ramp, delta)
    local distance = target - current
    local speed = distance > 0 and attack_speed or decay_speed
    local value = current + ramp * distance * speed * delta

    if (distance > 0 and value > target)
        or (distance < 0 and value < target)
    then
        value = target
    end

    return value
end

lag2d_new = function(x, y, speed, ramp)
    if speed == nil then speed = 1 end
    if ramp == nil then ramp = math_ln(1000) end
    log_typecheck(x, Number_t, y, Number_t, speed, Number_t, ramp, Number_t)

    return object_new(Lag2_t, {
        attack_speed = speed,
        decay_speed = speed,
        ramp = ramp,
        current_x = x,
        current_y = y,
        target_x = x,
        target_y = y,
    })
end

lag2d_get_position = function(self)
    log_typecheck(self, Lag2_t)
    return self.current_x, self.current_y
end

lag2d_get_target_position = function(self)
    log_typecheck(self, Lag2_t)
    return self.target_x, self.target_y
end

lag2d_set_position = function(self, x, y)
    log_typecheck(self, Lag2_t, x, Number_t, y, Number_t)
    self.current_x = x
    self.current_y = y
    return self
end

lag2d_set_target_position = function(self, x, y)
    log_typecheck(self, Lag2_t, x, Number_t, y, Number_t)
    self.target_x = x
    self.target_y = y
    return self
end

lag2d_skip = function(self)
    log_typecheck(self, Lag2_t)
    self.current_x = self.target_x
    self.current_y = self.target_y
    return self
end

lag2d_set_speed = function(self, attack_speed, decay_speed)
    if decay_speed == nil then decay_speed = attack_speed end
    log_typecheck(self, Lag2_t, attack_speed, Number_t, decay_speed, Number_t)
    self.attack_speed = attack_speed
    self.decay_speed = decay_speed
    return self
end

lag2d_update = function(self, delta)
    log_typecheck(self, Lag2_t, delta, Number_t)

    self.current_x = lag_step(
        self.current_x, self.target_x,
        self.attack_speed, self.decay_speed, self.ramp, delta)
    self.current_y = lag_step(
        self.current_y, self.target_y,
        self.attack_speed, self.decay_speed, self.ramp, delta)

    return self
end