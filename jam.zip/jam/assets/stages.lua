return {
  version = "1.10",
  luaversion = "5.1",
  tiledversion = "1.12.2",
  class = "",
  orientation = "orthogonal",
  renderorder = "right-down",
  width = 32,
  height = 32,
  tilewidth = 16,
  tileheight = 16,
  nextlayerid = 9,
  nextobjectid = 1353,
  properties = {},
  tilesets = {},
  layers = {
    {
      type = "imagelayer",
      image = "../../assets/tilesets/debug_tileset_16x16/tile.png",
      id = 3,
      name = "bg",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      repeatx = true,
      repeaty = true,
      properties = {}
    },
    {
      type = "objectgroup",
      draworder = "topdown",
      id = 8,
      name = "aux",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      objects = {}
    },
    {
      type = "objectgroup",
      draworder = "topdown",
      id = 7,
      name = "background",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      objects = {}
    },
    {
      type = "objectgroup",
      draworder = "topdown",
      id = 2,
      name = "base",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      objects = {
        {
          id = 1295,
          name = "jump_introduction",
          type = "Stage",
          shape = "rectangle",
          x = -320,
          y = -224,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "First Jumps",
            ["priority"] = -3
          }
        },
        {
          id = 1296,
          name = "",
          type = "Contour",
          shape = "polygon",
          x = 448,
          y = -192,
          width = 0,
          height = 0,
          rotation = 0,
          opacity = 1,
          visible = true,
          polygon = {
            { x = -224, y = 352 },
            { x = 16, y = -16 },
            { x = 32, y = 544 },
            { x = -112, y = 544 },
            { x = -224, y = 384 },
            { x = -256, y = 384 },
            { x = -304, y = 544 },
            { x = -752, y = 544 },
            { x = -752, y = -16 },
            { x = -256, y = -16 },
            { x = -256, y = 352 }
          },
          properties = {
            ["winding"] = false
          }
        },
        {
          id = 1300,
          name = "stage_02",
          type = "Stage",
          shape = "rectangle",
          x = 688,
          y = -224,
          width = 800,
          height = 1200,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "Liquidity"
          }
        },
        {
          id = 1301,
          name = "temp_07",
          type = "Stage",
          shape = "rectangle",
          x = -129.12,
          y = -1677.07,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #1"
          }
        },
        {
          id = 1302,
          name = "temp_06",
          type = "Stage",
          shape = "rectangle",
          x = 973.75,
          y = -1502.87,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #2"
          }
        },
        {
          id = 1303,
          name = "temp_05",
          type = "Stage",
          shape = "rectangle",
          x = 2121.77,
          y = -574.137,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #3"
          }
        },
        {
          id = 1304,
          name = "temp_04",
          type = "Stage",
          shape = "rectangle",
          x = 2050.19,
          y = 639.311,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #4"
          }
        },
        {
          id = 1305,
          name = "temp_03",
          type = "Stage",
          shape = "rectangle",
          x = 14.6473,
          y = 1177.81,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #5"
          }
        },
        {
          id = 1306,
          name = "temp_02",
          type = "Stage",
          shape = "rectangle",
          x = -1573.94,
          y = 445.45,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #6"
          }
        },
        {
          id = 1307,
          name = "temp_01",
          type = "Stage",
          shape = "rectangle",
          x = -1590.09,
          y = -986.968,
          width = 800,
          height = 800,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["name"] = "temp #7"
          }
        },
        {
          id = 1308,
          name = "",
          type = "Contour",
          shape = "polygon",
          x = 912,
          y = 96,
          width = 0,
          height = 0,
          rotation = 0,
          opacity = 1,
          visible = true,
          polygon = {
            { x = -64, y = -16 },
            { x = -64, y = 192 },
            { x = 384, y = 0 },
            { x = 240, y = -128 },
            { x = 176, y = 16 }
          },
          properties = {}
        }
      }
    },
    {
      type = "objectgroup",
      draworder = "topdown",
      id = 6,
      name = "foreground",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      objects = {
        {
          id = 1297,
          name = "",
          type = "Contour",
          shape = "polygon",
          x = -501.986,
          y = 188.539,
          width = 0,
          height = 0,
          rotation = 0,
          opacity = 1,
          visible = true,
          polygon = {
            { x = -32, y = -32 },
            { x = -80, y = 48 },
            { x = -128, y = 48 },
            { x = -176, y = -32 },
            { x = -192, y = -32 },
            { x = -192, y = 128 },
            { x = -16, y = 128 },
            { x = -16, y = -32 }
          },
          properties = {
            ["radius"] = 200,
            ["winding"] = false
          }
        },
        {
          id = 1299,
          name = "",
          type = "Spawn",
          shape = "point",
          x = -107.607,
          y = 185.04,
          width = 0,
          height = 0,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["radius"] = 200
          }
        },
        {
          id = 1309,
          name = "",
          type = "Spawn",
          shape = "point",
          x = 984.043,
          y = 78.0142,
          width = 0,
          height = 0,
          rotation = 0,
          opacity = 1,
          visible = true,
          properties = {
            ["radius"] = 200
          }
        }
      }
    },
    {
      type = "tilelayer",
      x = 0,
      y = 0,
      width = 32,
      height = 32,
      id = 1,
      name = "tiles",
      class = "",
      visible = true,
      opacity = 1,
      offsetx = 0,
      offsety = 0,
      parallaxx = 1,
      parallaxy = 1,
      properties = {},
      encoding = "lua",
      chunks = {}
    }
  }
}
